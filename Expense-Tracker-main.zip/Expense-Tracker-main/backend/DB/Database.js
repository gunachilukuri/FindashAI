import mongoose from "mongoose";

export const connectDB = async (req, res) => {
    const db ="mongodb+srv://charan:Kavya2805@cluster0.wufsgfu.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

    const {connection} = await mongoose.connect(db, { useNewUrlParser: true });

    console.log(`MongoDB Connected to ${connection.host}`);

}